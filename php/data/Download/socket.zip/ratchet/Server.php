<?php
namespace ChatApp;

require (dirname(__FILE__).'/vendor/autoload.php');
require (dirname(__FILE__).'/../php/Handler.php');

use API\Handler;
use Ratchet\Server\IoServer;
use Ratchet\Http\HttpServer;
use Ratchet\WebSocket\WsServer;
use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;


class Chat implements MessageComponentInterface {
    public $clients;
    public $clientIds;
    public $handler;

    public function __construct() {
        $this->clients = new \SplObjectStorage;
        $this->clientIds = array();
        $this->handler = new Handler($this);
    }

    public function onOpen(ConnectionInterface $conn) {
        $this->clients->attach($conn);

        $this->setUserInfo($conn);

        echo "New connection! ({$conn->resourceId})\n";

        $conn->send($this->prepareMessage(array("type" => "init", "id" => $conn->resourceId, "msg" => "Connected as ".$conn->resourceId)));
        foreach ($this->clients as $client) {
            if($client != $conn) {
                $conn->send($this->prepareMessage(array("type" => "userConnect", "msg" => "- ".$client->resourceId, "id" => $client->resourceId, "pos" => $client->pos)));
            }
        }

        $msg = array("type" => "userConnect", "msg" => "- ".$conn->resourceId, "id" => $conn->resourceId);
        $this->sendAllOther($msg, [$conn]);
    }

    public function onMessage(ConnectionInterface $from, $msg) {
        $this->handler->handle($from, $msg);
    }

    public function onClose(ConnectionInterface $conn) {

        $this->clients->detach($conn);

        echo "Connection {$conn->resourceId} has disconnected\n";

        $msg = array("type" => "userDisconnect", "id" => $conn->resourceId);
        $this->sendAllOther($msg, [$conn]);
    }

    public function onError(ConnectionInterface $conn, \Exception $e) {
        echo "An error has occurred: {$e->getMessage()}\n";

        $conn->close();
    }

    private function setUserInfo($conn) {
        $id = rand(1000, 9999);
        while(in_array($id, $this->clientIds)) {
            $id = rand(1000, 9999);
        }

//        $unique = false;
//
//        while($unique == false) {
//            foreach ($this->clients as $client) {
//                if($client->resourceId == $id) {
//                    $id = rand(1000, 9999);
//                    continue 2;
//                }
//            }
//            $unique = true;
//        }

        $conn->resourceId = $id;
        array_push($this->clientIds, $id);
    }

    public function prepareMessage($data = array()) {
        return json_encode($data);
    }

    public function sendOne($response, $client) {
        $client->send(json_encode($response));
    }

    public function sendAll($response) {
        foreach ($this->clients as $client) {
            $client->send(json_encode($response));
        }
    }

    public function sendAllOther($response, $prevent = array()) {
        foreach ($this->clients as $client) {
            if(!in_array($client, $prevent)) $client->send(json_encode($response));
        }
    }
}


$server = IoServer::factory(
    new HttpServer(
        new WsServer(
            new Chat()
        )
    ),
    9010
);

$server->run();