<?php

namespace API;

include_once (dirname(__FILE__)."/Classes/ChatFunc.php");
include_once (dirname(__FILE__)."/Classes/HoverFunc.php");

use ChatFunc;
use HoverFunc;
use Ratchet\Wamp\Exception;

class Handler {

    private $ws;

    public function __construct($ws) {
        $this->ws = $ws;
    }

    public function handle($from, $msg) {
        $data = json_decode($msg, true);

        switch ($data["controller"]) {
            case "chat":
                $objRef = new ChatFunc($this->ws, $from, $data);
                break;
            case "hover":
                $objRef = new HoverFunc($this->ws, $from, $data);
                break;
        }

        try {
            $objRef->{$data["action"]}();
        } catch(Exception $e) {

        }
    }
}