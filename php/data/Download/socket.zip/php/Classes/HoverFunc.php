<?php

class HoverFunc {

    private $ws;
    private $from;
    private $data;

    public function __construct($ws, $from, $data) {
        $this->ws = $ws;
        $this->from = $from;
        $this->data = $data;
    }

    public function updatePlayerPos() {
        $this->from->pos = $this->data["pos"];
        $response = array(
            "type" => "hover",
            "id" => $this->from->resourceId,
            "pos" => $this->data["pos"]
        );

        $this->ws->sendAllOther($response, [$this->from]);
    }
}

?>