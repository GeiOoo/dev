<?php

class ChatFunc {

    private $ws;
    private $from;
    private $data;

    public function __construct($ws, $from, $data) {
        $this->ws = $ws;
        $this->from = $from;
        $this->data = $data;

        $this->data["msg"] = htmlentities($this->data["msg"], ENT_COMPAT, "UTF-8", false);
    }

    public function newMessage() {
        $msgTo = $this->from->resourceId.": ".$this->data["msg"];
        $msgFrom = "<b>".$this->from->resourceId.":</b> ".$this->data["msg"];
        $responseTo = array("type" => "chat", "msg" => $msgTo);
        $responseFrom = array("type" => "chat", "msg" => $msgFrom);

        $this->ws->sendOne($responseFrom, $this->from);
        $this->ws->sendAllOther($responseTo, [$this->from]);
    }
}

?>