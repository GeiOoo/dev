$(document).ready(function () {
    new Socket();
});