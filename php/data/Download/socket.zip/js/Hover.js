function Hover(id, controll) {

    var me = this;
    me.elem = $("<div id='"+id+"'><label>."+id+"</label></div>").appendTo("#hover");
    me.elem.data("obj", me);

    if(controll) {
        $("#hover").on("mousemove", function (e) {
            let hover = $(this);

            me.pos = {
                x: e.clientX - hover.offset().left - 6,
                y: e.clientY - hover.offset().top - 6
            };

            me.updatePos(me.pos);

            me.elem.trigger("moved");
        });
    }

    me.updatePos = function (pos) {
        me.elem.css({
            top: pos.y+"px",
            left: pos.x+"px"
        });
    };

    return me.elem;
}