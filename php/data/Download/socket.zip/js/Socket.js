function Socket() {
    var wsUri = "wss://ws.geiooo.de",
        ws = new WebSocket(wsUri),
        me = this,
        reconId = false;

    me.connected = false;

    ws.onopen = function(e) {
        console.log("Connection established");
        me.connected = true;
    };

    ws.onerror = function(e){
        console.log("Error Occurred - "+e.data);
    };

    ws.onclose = function(e){
        console.log("Connection Closed");
        me.connected = false;
        $("#hover>div:first-child").remove();
        $("#user>div:first-child").remove();

        reconId = setInterval(function () {
            var temp = new Socket();
            setTimeout(function () {
                if(temp && temp.connected && reconId) {
                    clearInterval(reconId);
                    ws.send = function () {

                    };
                }
            }, 2000)
        }, 5000);
    };

    ws.onmessage = function (e) {
        me.handleMessage(JSON.parse(e.data));
    };

    me.handleMessage = function(data) {
        switch(data.type) {
            case 'chat':
                $('#output').append("<div>"+data.msg+"</div>").scrollTop($("#output").height());
                break;
            case "userConnect":
                if(data.id) new Hover(data.id, false);
                $('#online').append("<div id='user"+data.id+"'>"+data.msg+"</div>").scrollTop($("#online").height());
                if(data.pos)$("#"+data.id).data("obj").updatePos(data.pos);
                break;
            case "userDisconnect":
                if(data.id) {
                    $("#"+data.id).remove();
                    $("#user"+data.id).remove();
                }
                break;
            case "init":
                $('#user').append("<div>" +
                    "<div>"+data.msg+"</div>" +
                    "<div>Online:</div>" +
                    "<div id='online'></div>" +
                    "</div>");
                var elem = new Hover(data.id, true);
                elem.on("moved", function () {
                    ws.send(
                        JSON.stringify({
                            'controller': 'hover',
                            'action': 'updatePlayerPos',
                            'pos': elem.data("obj").pos
                        })
                    );
                });
                break;
            case "hover":
                var obj = $("#"+data.id).data("obj");
                if(obj)obj.updatePos(data.pos);
                break;
            case "close": {
                break;
            }
        }
    };

    $('#input').on('keyup',function(e){
        if(e.keyCode==13 && !e.shiftKey)
        {
            var chat_msg = $(this).val();
            ws.send(
                JSON.stringify({
                    'controller': 'chat',
                    'action': 'newMessage',
                    'msg':chat_msg
        })
        );
            $(this).val('');
        }
    });


}