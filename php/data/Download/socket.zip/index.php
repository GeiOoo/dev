<!DOCTYPE html>
<html>
<head>
    <title>Chat</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/main.js"></script>
    <script src="js/Socket.js"></script>
    <script src="js/Hover.js"></script>
</head>
<body>
<div id="content">
    <div id="hover" class="frame"></div>
    <div id="chat">
        <div id="output" class="frame"></div>
        <div id="user" class="frame"></div>
    </div>
    <input type="text" id="input" class="frame" placeholder="Enter Text">
</div>
</body>
</html>