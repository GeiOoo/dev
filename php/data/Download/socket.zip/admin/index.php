<?php

header("Location: https://app.pm2.io/#/bucket/5b55921860aa32a48497da4a/overview/apps");
exit;