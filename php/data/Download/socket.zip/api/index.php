<?php

popen("php ../ratchet/server.php", "r");

?>