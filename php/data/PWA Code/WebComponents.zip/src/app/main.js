/*
import {ArticlesService} from "./articlesModule/services/ArticlesService.js";

const articlesService = new ArticlesService();

articlesService.getAllArticles().then((articles) => {
    console.log('Artikel: ', articles);
});
*/
