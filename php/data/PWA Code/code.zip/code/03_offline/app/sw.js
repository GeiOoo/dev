const errorPage = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<div class="container">
    <h1>Service Worker</h1>
    <div class="row">
        <div class="col-md-4">
            <h2>Lorem ipsum.</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Alias aperiam cumque, fuga ipsum nulla quos
                repellendus voluptatum! Delectus deserunt, eaque harum ipsum iure molestiae nam neque nihil quibusdam
                sint sit!</p>
        </div>
        <div class="col-md-4">
            <h2>Atque, impedit!</h2>
            <p>Ad, animi assumenda explicabo fuga illo incidunt ipsa ipsam iste iure nam odio omnis optio provident quas
                quasi ratione rem rerum sapiente, sed similique suscipit tenetur ullam velit vero voluptate!</p>
        </div>
        <div class="col-md-4">
            <h2>Suscipit, unde!</h2>
            <p>Dicta doloremque et illo incidunt, libero nostrum optio perspiciatis possimus provident, quam saepe
                voluptatum! Id iste maxime officia omnis voluptatum. Deserunt et exercitationem hic incidunt iusto minus
                molestias quibusdam unde!</p>
        </div>
    </div>
</div>

</body>
</html>
`;

self.addEventListener("fetch", (e) => {
    e.respondWith(fetch(e.request).catch(() => {
        return new Response(errorPage, {headers: {"Content-Type": "text/html"}})
    }));
});