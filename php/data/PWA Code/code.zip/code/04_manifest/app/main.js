if('serviceWorker' in navigator) {
    navigator
        .serviceWorker
        .register('sw.js')
        .then(function (registration) {
            console.log('Registriert für: ' + registration.scope);
        })
} else {
    console.info('no pwa capability');
}

