const errorPage = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <style>
    body {
    text-align: center;
    }
    h1 {
    font-weight: normal;
    }
</style>
</head>
<body>
    <h1>Sorry - Offline</h1>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusamus at eos fugiat natus nobis officia
        qui, recusandae vitae voluptas? A ad aperiam commodi eaque, eos itaque libero officia optio
        recusandae.</p>
</body>
</html>
`;


self.addEventListener('fetch', (event) => {
    event.respondWith(fetch(event.request).catch(() => {
        return new Response(errorPage, {headers: {"Content-Type": "text/html"}});
    }));

    console.log('fetch event triggered');
});
