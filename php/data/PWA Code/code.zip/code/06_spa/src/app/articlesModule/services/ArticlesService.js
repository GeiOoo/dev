window.ACME = window.ACME || {};

// Modul Pattern
window.ACME.ArticlesService = (function (http) {
    "use strict";
    var baseUrl = "http://localhost:3000/articles";
    function ArticlesService() {

    }
    ArticlesService.prototype.getAllArticles = function (cb) {
        http.get(baseUrl, cb);
    };

    return ArticlesService;

}(window.ACME.http));
