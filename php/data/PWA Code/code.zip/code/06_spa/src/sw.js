const CACHE_URL = [
    // HTML
    "/",
    "index.html",

    //CSS
    "vendor/css/bootstrap.min.css",

    // 3rd party javascript
    "vendor/js/modernizr-custom.js",
    "vendor/js/jquery-3.4.1.min.js",
    "vendor/js/bootstrap.bundle.min.js",

    // Javascript
    "app/lib/http.js",
    "app/articlesModule/services/ArticlesService.js",
    "app/articlesModule/components/ArticleListComponent.js",
    "app/main.js",

    // APIs
    "articles"
];


const errorPage = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <style>
    body {
    text-align: center;
    }
    h1 {
    font-weight: normal;
    }
</style>
</head>
<body>
    <h1>Sorry - Offline</h1>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusamus at eos fugiat natus nobis officia
        qui, recusandae vitae voluptas? A ad aperiam commodi eaque, eos itaque libero officia optio
        recusandae.</p>
</body>
</html>
`;

const CACHE_NAME = "littl-crm";
self.addEventListener("install", (event) => {
    event.waitUntil(caches.open(CACHE_NAME).then((cache) => {
        return cache.addAll(CACHE_URL);
    }))
});

self.addEventListener("fetch", (event) => {

    let url = new URL(event.request.url);

    if (url.pathname === '/articles') {

        event.respondWith(caches.open(CACHE_NAME).then((cache) => {

            return fetch(event.request)

                // Wenn online
                .then((networkResponse) => {
                    // Cache updaten
                    cache.put(event.request, networkResponse.clone());

                    // Daten anzeigen
                    return networkResponse;
                })

            // Wenn offline
                .catch(() => {
                    // Daten aus Cache holen
                    return cache.match(event.request);
                })

        }));

    } else {

        event.respondWith(fetch(event.request).catch((err) => {
            console.log('err: ', err);
            return caches.match(event.request)
                .then((cacheEntry) => {
                    if (cacheEntry) {
                        return cacheEntry;
                    } else if (event.request.headers.get("accept").includes("text/html")) {
                        return new Response(errorPage, {headers: {"Content-Type": "text/html"}});
                        // return cache.match('offline.html')
                    }
                });
        }));

    }
});
