self.addEventListener("install", (e) => {
    console.log(e);
});

self.addEventListener("activate", (e) => {
    console.log(e);
});

self.addEventListener("fetch", (e) => {
    console.log(e);
});