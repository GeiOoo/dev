const CACHE_URL = [
    // HTML
    "/",
    "index.html",
    "404.html",

    // CSS
    "vendor/css/bootstrap.min.css",

    // JS
    "vendor/js/modernizr-custom.js",
    "vendor/js/jquery-3.4.1.min.js",
    "vendor/js/bootstrap.bundle.min.js",
    "app/lib/http.js",

    "app/articlesModule/services/ArticlesService.js",
    "app/articlesModule/components/ArticleListComponent.js",
    "app/main.js",

    // API
    "/articles"
];
const CACHE_NAME = "little-pwa";

self.addEventListener("install", (e) => {
    e.waitUntil(caches.open(CACHE_NAME).then((cache) => {
        return cache.addAll(CACHE_URL);
    }));
});

self.addEventListener("fetch", (e) => {
    e.respondWith(fetch(e.request).catch((response) => {
        return caches.open(CACHE_NAME).then((cache) => {
            return cache.match(e.request).then((response) => {
                if(response) return response;
                else throw new Error("File not found");
            }).catch((error) => {
                return cache.match("404.html").then((response) => {
                    return new Response(response.body, {headers: {"Content-Type": "text/html"}});
                });
            });
        }).catch((e) => {
            if(e.request.referrer === "") {
                e.respondWith(new Response(errorPage, {headers: {"Content-Type": "text/html"}}));
            }
        });
    }));
});