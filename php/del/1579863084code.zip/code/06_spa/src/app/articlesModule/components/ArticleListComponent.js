window.ACME = window.ACME || {};

// Modul Pattern
window.ACME.ArticleListComponent = (function (articlesService) {
    "use strict";

    function ArticleListComponent(selector) {
        var templateElement = document.querySelector(selector);
        var templateHTML = templateElement.innerHTML;

        articlesService.getAllArticles(function (data) {
            var output = '';
            data.forEach(function (item) {
                var template = templateHTML;

                Object.keys(item).forEach(function (key) {
                    var p = '{{' + key + '}}';
                    template = template.replace(p, item[key]);
                });

                output += template;
            });

            templateElement.innerHTML = output;

        })
    }

    return ArticleListComponent;

}(new window.ACME.ArticlesService()));
